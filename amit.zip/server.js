const app = require("./src/index");
const connect = require("./src/configs/db");

const port=process.env.PORT || 2000

app.listen(port, async function () {
  try {
    await connect();
    console.log(`listening on port ${port}`);
  } catch (err) {
    console.log(err);
  }
});
