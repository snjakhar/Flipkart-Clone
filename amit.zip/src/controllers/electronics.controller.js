const express=require("express")

const router=express.Router()

const Electronics=require("../models/electronics.model")

// router.get("",async(req,res)=>{
// try{
//   const electronics=await Electronics.find().lean().exec()
//   return res.status(200).send(electronics)
// }catch(e){
//     return res.status(400).send(e.message)
// }
// })

router.get("",async(req,res)=>{
    try{
        const filter = req.query.filter
        const rating = req.query.rating
        console.log(filter,rating)
       if(filter=="low")
      {
        const electronics=await Electronics.find().sort({price:1}).lean().exec()
        return res.status(200).send(electronics)
      }
      else if(filter=="high")
      {
        const electronics=await Electronics.find().sort({price:-1}).lean().exec()
        return res.status(200).send(electronics)
      }
       
      if(rating=="low")
      {
        const electronics=await Electronics.find().sort({rating:1}).lean().exec()
        return res.status(200).send(electronics)
      }
      else if(rating=="high")
      {
        const electronics=await Electronics.find().sort({rating:-1}).lean().exec()
        return res.status(200).send(electronics)
      }

      const electronics=await Electronics.find().lean().exec()
        return res.status(200).send(electronics)
    }catch(e){
        return res.status(400).send(e.message)
    }
    })


module.exports=router