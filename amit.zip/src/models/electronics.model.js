const mongoose=require("mongoose")

const electronicsShcema=new mongoose.Schema({

})

module.exports=mongoose.model("electronics",electronicsShcema)