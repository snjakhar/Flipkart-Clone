 const mongoose=require("mongoose")

 module.exports=()=>{
     return mongoose.connect("mongodb+srv://jangidamit358:Jangid123@cluster0.x3tms.mongodb.net/Akhil")
 }